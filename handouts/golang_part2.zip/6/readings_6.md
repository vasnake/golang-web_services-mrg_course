* http://www.vividcortex.com/hubfs/eBooks/The_Ultimate_Guide_To_Building_Database-Driven_Apps_with_Go.pdf - в удобной форме информация по основным аспектам работы с database/sql
* https://golang.org/pkg/database/sql/ - собственно сам интерфейс к базе
* https://github.com/golang/go/wiki/SQLDrivers - список поддерживаемых баз
* https://github.com/golang/go/wiki/SQLInterface
* https://github.com/DATA-DOG/go-sqlmock
* http://www.alexedwards.net/blog/configuring-sqldb
* http://go-database-sql.org/
* https://astaxie.gitbooks.io/build-web-application-with-golang/
* https://github.com/thewhitetulip/web-dev-golang-anti-textbook/
* https://codegangsta.gitbooks.io/building-web-apps-with-go/content/
* https://godoc.org/github.com/go-sql-driver/mysql
* https://godoc.org/github.com/lib/pq
* https://godoc.org/github.com/bradfitz/gomemcache/memcache
* https://godoc.org/github.com/garyburd/redigo/redis
* https://godoc.org/gopkg.in/mgo.v2
* http://goinbigdata.com/how-to-build-microservice-with-mongodb-in-golang/
* http://gorm.io/
* http://motion-express.com/blog/gorm:-a-simple-guide-on-crud
* https://godoc.org/github.com/jinzhu/gorm
* https://habrahabr.ru/company/mailru/blog/266811/ - архи-полезная статья про устройство базы внутри
* https://hackernoon.com/communicating-go-applications-through-redis-pub-sub-messaging-paradigm-df7317897b13
* https://medium.com/@shijuvar/introducing-nats-to-go-developers-3cfcb98c21d0
* https://medium.com/@shijuvar/building-distributed-systems-and-microservices-in-go-with-nats-streaming-d8b4baa633a2
