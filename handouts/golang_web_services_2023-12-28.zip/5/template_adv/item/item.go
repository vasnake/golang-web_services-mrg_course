package item

type Item struct {
	Id          int
	Title       string
	Description string
}
