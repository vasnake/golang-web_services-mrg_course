package main

import (
	_ "github.com/DATA-DOG/go-sqlmock"
	_ "github.com/go-playground/assert/v2"
	_ "github.com/go-sql-driver/mysql"
	_ "github.com/golang-jwt/jwt"

	// _ "github.com/golang/mock"
	_ "github.com/gorilla/mux"
	_ "github.com/jinzhu/gorm"
	_ "github.com/jmoiron/sqlx"
	_ "github.com/stretchr/testify"
)
