#include "_cgo_export.h"

extern void printResultGolang(int i);

void Multiply(int a, int b) {
    printResultGolang(a*b);
}