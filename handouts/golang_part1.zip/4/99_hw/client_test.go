package main

// код писать тут