package main

func main() {
	println("usage: go test -v")
}
