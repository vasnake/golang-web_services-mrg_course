https://github.com/Masterminds/glide

glide create

glide get google.golang.org/grpc

glide install

go build 

glide up

glide list