Это пример из 3-й лекции 1-й части курса.

Запускать, находясь в этой папке, так:

``` shell
go build gen/* && ./codegen.exe pack/unpack.go  pack/marshaller.go
go run pack/*
```

Естественно расширение `exe` только для windows-платформ